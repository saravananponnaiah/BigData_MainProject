CREATE DATABASE IF NOT EXISTS company;

USE company;

CREATE TABLE IF NOT EXISTS tbl_company
(
company_code VARCHAR(10),
company_name VARCHAR(50),
location VARCHAR(20),
status INT
);

commit;
