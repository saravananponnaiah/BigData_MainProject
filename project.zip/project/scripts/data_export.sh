#!/bin/bash

#This script is not working.
#Either change table to text or use STRING as type of partitioned column
echo "STARTING DATA EXPORT TO MYSQL"
batchid=`cat /home/acadgild/project/logs/current-batch.txt`
LOGFILE=/home/acadgild/project/logs/log_batch_$batchid
echo "Setting log file path..."
echo $batchid
echo $LOGFILE
echo "Creating mysql tables if not present..." >> $LOGFILE
#mysql -u root < /home/acadgild/project/scripts/create_schema.sql
#mysql --user=root --password=Root@123 --database=project < /home/acadgild/project/scripts/create_schema.sql
echo "Running sqoop job for data export..." >> $LOGFILE
echo "Source: "
echo "hdfs://localhost:8020/user/hive/warehouse/project.db/top_10_stations/batchid=$batchid"

sqoop export --connect jdbc:mysql://localhost/project --username 'root' --password 'Root@123' --table top_10_stations --export-dir hdfs://localhost:8020/user/hive/warehouse/project.db/top_10_stations/batchid=1 --input-fields-terminated-by ',' -m 1

sqoop export --connect jdbc:mysql://localhost/project --username 'root' --password 'Root@123' --table users_behaviour --export-dir hdfs://localhost:8020/user/hive/warehouse/project.db/users_behaviour/batchid=1 --input-fields-terminated-by ',' -m 1

sqoop export --connect jdbc:mysql://localhost/project --username 'root' --password 'Root@123' --table connected_artists --export-dir hdfs://localhost:8020/user/hive/warehouse/project.db/connected_artists/batchid=1 --input-fields-terminated-by ',' -m 1

sqoop export --connect jdbc:mysql://localhost/project --username 'root' --password 'Root@123' --table top_10_royalty_songs --export-dir hdfs://localhost:8020/user/hive/warehouse/project.db/top_10_royalty_songs/batchid=1 --input-fields-terminated-by ',' -m 1

sqoop export --connect jdbc:mysql://localhost/project --username 'root' --password 'Root@123' --table top_10_unsubscribed_users --export-dir hdfs://localhost:8020/user/hive/warehouse/project.db/top_10_unsubscribed_users/batchid=1 --input-fields-terminated-by ',' -m 1
